package com.mycompany.homerental

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
