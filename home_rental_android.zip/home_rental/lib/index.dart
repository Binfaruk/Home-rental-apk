// Export pages
export '/pages/entry/entry_widget.dart' show EntryWidget;
export '/pages/login/login_widget.dart' show LoginWidget;
export '/pages/home/home_widget.dart' show HomeWidget;
export '/owner/upload_info/upload_info_widget.dart' show UploadInfoWidget;
export '/extra/owner_upload/owner_upload_widget.dart' show OwnerUploadWidget;
export '/extra/owner_booked/owner_booked_widget.dart' show OwnerBookedWidget;
export '/owner/upload_details/upload_details_widget.dart'
    show UploadDetailsWidget;
export '/tanent/tanent_home/tanent_home_widget.dart' show TanentHomeWidget;
export '/tanent/house_details/house_details_widget.dart'
    show HouseDetailsWidget;
export '/tanent/paymentmethod/paymentmethod_widget.dart'
    show PaymentmethodWidget;
export '/tanent/b_kash/b_kash_widget.dart' show BKashWidget;
export '/tanent/sucessful/sucessful_widget.dart' show SucessfulWidget;
export '/admin/admin_login/admin_login_widget.dart' show AdminLoginWidget;
export '/admin/admin_home/admin_home_widget.dart' show AdminHomeWidget;
export '/pages/registration/registration_widget.dart' show RegistrationWidget;
export '/extra/pending_uploads/pending_uploads_widget.dart'
    show PendingUploadsWidget;
export '/extra/view/view_widget.dart' show ViewWidget;
export '/owner/owner_home/owner_home_widget.dart' show OwnerHomeWidget;
export '/admin/details/details_widget.dart' show DetailsWidget;
export '/admin/view_profile_owner/view_profile_owner_widget.dart'
    show ViewProfileOwnerWidget;
export '/owner/profile/profile_widget.dart' show ProfileWidget;
export '/tanent/profile_tanent/profile_tanent_widget.dart'
    show ProfileTanentWidget;
export '/tanent/booked_house/booked_house_widget.dart' show BookedHouseWidget;
export '/extra/otp/otp_widget.dart' show OtpWidget;
export '/pages/forget_password/forget_password_widget.dart'
    show ForgetPasswordWidget;
export '/tanent/view_owner_profile/view_owner_profile_widget.dart'
    show ViewOwnerProfileWidget;
export '/tanent/report/report_widget.dart' show ReportWidget;
export '/owner/view_tanent_profile/view_tanent_profile_widget.dart'
    show ViewTanentProfileWidget;
export '/tanent/report_tanent/report_tanent_widget.dart'
    show ReportTanentWidget;
export '/admin/view_profile_tanent/view_profile_tanent_widget.dart'
    show ViewProfileTanentWidget;
export '/tanent/b_kash_payment/b_kash_payment_widget.dart'
    show BKashPaymentWidget;
export '/tanent/b_kash_payment_verify/b_kash_payment_verify_widget.dart'
    show BKashPaymentVerifyWidget;
export '/tanent/b_kash_pin/b_kash_pin_widget.dart' show BKashPinWidget;
export '/admin/report_list/report_list_widget.dart' show ReportListWidget;
