import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

Future initFirebase() async {
  if (kIsWeb) {
    await Firebase.initializeApp(
        options: FirebaseOptions(
            apiKey: "AIzaSyA51w2Oa2isR4seSDrt8SdAY1vzJHxwaY4",
            authDomain: "home-rental-95e37.firebaseapp.com",
            projectId: "home-rental-95e37",
            storageBucket: "home-rental-95e37.appspot.com",
            messagingSenderId: "108342808869",
            appId: "1:108342808869:web:471183c3982279e8744acc",
            measurementId: "G-VCKRK6MEKP"));
  } else {
    await Firebase.initializeApp();
  }
}
