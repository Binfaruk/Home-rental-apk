import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class HouseinfoRecord extends FirestoreRecord {
  HouseinfoRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "type" field.
  String? _type;
  String get type => _type ?? '';
  bool hasType() => _type != null;

  // "location" field.
  String? _location;
  String get location => _location ?? '';
  bool hasLocation() => _location != null;

  // "floor_info" field.
  String? _floorInfo;
  String get floorInfo => _floorInfo ?? '';
  bool hasFloorInfo() => _floorInfo != null;

  // "facilities" field.
  String? _facilities;
  String get facilities => _facilities ?? '';
  bool hasFacilities() => _facilities != null;

  // "restrictions" field.
  String? _restrictions;
  String get restrictions => _restrictions ?? '';
  bool hasRestrictions() => _restrictions != null;

  // "contact" field.
  String? _contact;
  String get contact => _contact ?? '';
  bool hasContact() => _contact != null;

  // "available_date" field.
  DateTime? _availableDate;
  DateTime? get availableDate => _availableDate;
  bool hasAvailableDate() => _availableDate != null;

  // "photo1" field.
  String? _photo1;
  String get photo1 => _photo1 ?? '';
  bool hasPhoto1() => _photo1 != null;

  // "photo2" field.
  String? _photo2;
  String get photo2 => _photo2 ?? '';
  bool hasPhoto2() => _photo2 != null;

  // "photo3" field.
  String? _photo3;
  String get photo3 => _photo3 ?? '';
  bool hasPhoto3() => _photo3 != null;

  // "rent_amount" field.
  String? _rentAmount;
  String get rentAmount => _rentAmount ?? '';
  bool hasRentAmount() => _rentAmount != null;

  // "user_email" field.
  String? _userEmail;
  String get userEmail => _userEmail ?? '';
  bool hasUserEmail() => _userEmail != null;

  // "rooms" field.
  String? _rooms;
  String get rooms => _rooms ?? '';
  bool hasRooms() => _rooms != null;

  // "approved" field.
  bool? _approved;
  bool get approved => _approved ?? false;
  bool hasApproved() => _approved != null;

  // "booked" field.
  bool? _booked;
  bool get booked => _booked ?? false;
  bool hasBooked() => _booked != null;

  // "tanent_booked" field.
  String? _tanentBooked;
  String get tanentBooked => _tanentBooked ?? '';
  bool hasTanentBooked() => _tanentBooked != null;

  void _initializeFields() {
    _type = snapshotData['type'] as String?;
    _location = snapshotData['location'] as String?;
    _floorInfo = snapshotData['floor_info'] as String?;
    _facilities = snapshotData['facilities'] as String?;
    _restrictions = snapshotData['restrictions'] as String?;
    _contact = snapshotData['contact'] as String?;
    _availableDate = snapshotData['available_date'] as DateTime?;
    _photo1 = snapshotData['photo1'] as String?;
    _photo2 = snapshotData['photo2'] as String?;
    _photo3 = snapshotData['photo3'] as String?;
    _rentAmount = snapshotData['rent_amount'] as String?;
    _userEmail = snapshotData['user_email'] as String?;
    _rooms = snapshotData['rooms'] as String?;
    _approved = snapshotData['approved'] as bool?;
    _booked = snapshotData['booked'] as bool?;
    _tanentBooked = snapshotData['tanent_booked'] as String?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('houseinfo');

  static Stream<HouseinfoRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => HouseinfoRecord.fromSnapshot(s));

  static Future<HouseinfoRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => HouseinfoRecord.fromSnapshot(s));

  static HouseinfoRecord fromSnapshot(DocumentSnapshot snapshot) =>
      HouseinfoRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static HouseinfoRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      HouseinfoRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'HouseinfoRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is HouseinfoRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createHouseinfoRecordData({
  String? type,
  String? location,
  String? floorInfo,
  String? facilities,
  String? restrictions,
  String? contact,
  DateTime? availableDate,
  String? photo1,
  String? photo2,
  String? photo3,
  String? rentAmount,
  String? userEmail,
  String? rooms,
  bool? approved,
  bool? booked,
  String? tanentBooked,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'type': type,
      'location': location,
      'floor_info': floorInfo,
      'facilities': facilities,
      'restrictions': restrictions,
      'contact': contact,
      'available_date': availableDate,
      'photo1': photo1,
      'photo2': photo2,
      'photo3': photo3,
      'rent_amount': rentAmount,
      'user_email': userEmail,
      'rooms': rooms,
      'approved': approved,
      'booked': booked,
      'tanent_booked': tanentBooked,
    }.withoutNulls,
  );

  return firestoreData;
}

class HouseinfoRecordDocumentEquality implements Equality<HouseinfoRecord> {
  const HouseinfoRecordDocumentEquality();

  @override
  bool equals(HouseinfoRecord? e1, HouseinfoRecord? e2) {
    return e1?.type == e2?.type &&
        e1?.location == e2?.location &&
        e1?.floorInfo == e2?.floorInfo &&
        e1?.facilities == e2?.facilities &&
        e1?.restrictions == e2?.restrictions &&
        e1?.contact == e2?.contact &&
        e1?.availableDate == e2?.availableDate &&
        e1?.photo1 == e2?.photo1 &&
        e1?.photo2 == e2?.photo2 &&
        e1?.photo3 == e2?.photo3 &&
        e1?.rentAmount == e2?.rentAmount &&
        e1?.userEmail == e2?.userEmail &&
        e1?.rooms == e2?.rooms &&
        e1?.approved == e2?.approved &&
        e1?.booked == e2?.booked &&
        e1?.tanentBooked == e2?.tanentBooked;
  }

  @override
  int hash(HouseinfoRecord? e) => const ListEquality().hash([
        e?.type,
        e?.location,
        e?.floorInfo,
        e?.facilities,
        e?.restrictions,
        e?.contact,
        e?.availableDate,
        e?.photo1,
        e?.photo2,
        e?.photo3,
        e?.rentAmount,
        e?.userEmail,
        e?.rooms,
        e?.approved,
        e?.booked,
        e?.tanentBooked
      ]);

  @override
  bool isValidKey(Object? o) => o is HouseinfoRecord;
}
