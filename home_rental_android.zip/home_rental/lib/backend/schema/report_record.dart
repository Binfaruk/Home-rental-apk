import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class ReportRecord extends FirestoreRecord {
  ReportRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "message" field.
  String? _message;
  String get message => _message ?? '';
  bool hasMessage() => _message != null;

  // "reporting_email" field.
  String? _reportingEmail;
  String get reportingEmail => _reportingEmail ?? '';
  bool hasReportingEmail() => _reportingEmail != null;

  // "reporting_id" field.
  String? _reportingId;
  String get reportingId => _reportingId ?? '';
  bool hasReportingId() => _reportingId != null;

  // "reporter_email" field.
  String? _reporterEmail;
  String get reporterEmail => _reporterEmail ?? '';
  bool hasReporterEmail() => _reporterEmail != null;

  // "reporter_role" field.
  String? _reporterRole;
  String get reporterRole => _reporterRole ?? '';
  bool hasReporterRole() => _reporterRole != null;

  void _initializeFields() {
    _message = snapshotData['message'] as String?;
    _reportingEmail = snapshotData['reporting_email'] as String?;
    _reportingId = snapshotData['reporting_id'] as String?;
    _reporterEmail = snapshotData['reporter_email'] as String?;
    _reporterRole = snapshotData['reporter_role'] as String?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('report');

  static Stream<ReportRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => ReportRecord.fromSnapshot(s));

  static Future<ReportRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => ReportRecord.fromSnapshot(s));

  static ReportRecord fromSnapshot(DocumentSnapshot snapshot) => ReportRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static ReportRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      ReportRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'ReportRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is ReportRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createReportRecordData({
  String? message,
  String? reportingEmail,
  String? reportingId,
  String? reporterEmail,
  String? reporterRole,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'message': message,
      'reporting_email': reportingEmail,
      'reporting_id': reportingId,
      'reporter_email': reporterEmail,
      'reporter_role': reporterRole,
    }.withoutNulls,
  );

  return firestoreData;
}

class ReportRecordDocumentEquality implements Equality<ReportRecord> {
  const ReportRecordDocumentEquality();

  @override
  bool equals(ReportRecord? e1, ReportRecord? e2) {
    return e1?.message == e2?.message &&
        e1?.reportingEmail == e2?.reportingEmail &&
        e1?.reportingId == e2?.reportingId &&
        e1?.reporterEmail == e2?.reporterEmail &&
        e1?.reporterRole == e2?.reporterRole;
  }

  @override
  int hash(ReportRecord? e) => const ListEquality().hash([
        e?.message,
        e?.reportingEmail,
        e?.reportingId,
        e?.reporterEmail,
        e?.reporterRole
      ]);

  @override
  bool isValidKey(Object? o) => o is ReportRecord;
}
