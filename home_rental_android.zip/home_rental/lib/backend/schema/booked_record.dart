import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class BookedRecord extends FirestoreRecord {
  BookedRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "type" field.
  String? _type;
  String get type => _type ?? '';
  bool hasType() => _type != null;

  // "location" field.
  String? _location;
  String get location => _location ?? '';
  bool hasLocation() => _location != null;

  // "floor_info" field.
  String? _floorInfo;
  String get floorInfo => _floorInfo ?? '';
  bool hasFloorInfo() => _floorInfo != null;

  // "facilities" field.
  String? _facilities;
  String get facilities => _facilities ?? '';
  bool hasFacilities() => _facilities != null;

  // "restrictions" field.
  String? _restrictions;
  String get restrictions => _restrictions ?? '';
  bool hasRestrictions() => _restrictions != null;

  // "contact" field.
  String? _contact;
  String get contact => _contact ?? '';
  bool hasContact() => _contact != null;

  // "available_date" field.
  DateTime? _availableDate;
  DateTime? get availableDate => _availableDate;
  bool hasAvailableDate() => _availableDate != null;

  // "photo1" field.
  String? _photo1;
  String get photo1 => _photo1 ?? '';
  bool hasPhoto1() => _photo1 != null;

  // "photo2" field.
  String? _photo2;
  String get photo2 => _photo2 ?? '';
  bool hasPhoto2() => _photo2 != null;

  // "photo3" field.
  String? _photo3;
  String get photo3 => _photo3 ?? '';
  bool hasPhoto3() => _photo3 != null;

  // "rent_amount" field.
  String? _rentAmount;
  String get rentAmount => _rentAmount ?? '';
  bool hasRentAmount() => _rentAmount != null;

  // "rooms" field.
  String? _rooms;
  String get rooms => _rooms ?? '';
  bool hasRooms() => _rooms != null;

  // "booked" field.
  bool? _booked;
  bool get booked => _booked ?? false;
  bool hasBooked() => _booked != null;

  // "owner_email" field.
  String? _ownerEmail;
  String get ownerEmail => _ownerEmail ?? '';
  bool hasOwnerEmail() => _ownerEmail != null;

  // "tanent_email" field.
  String? _tanentEmail;
  String get tanentEmail => _tanentEmail ?? '';
  bool hasTanentEmail() => _tanentEmail != null;

  // "paid" field.
  String? _paid;
  String get paid => _paid ?? '';
  bool hasPaid() => _paid != null;

  void _initializeFields() {
    _type = snapshotData['type'] as String?;
    _location = snapshotData['location'] as String?;
    _floorInfo = snapshotData['floor_info'] as String?;
    _facilities = snapshotData['facilities'] as String?;
    _restrictions = snapshotData['restrictions'] as String?;
    _contact = snapshotData['contact'] as String?;
    _availableDate = snapshotData['available_date'] as DateTime?;
    _photo1 = snapshotData['photo1'] as String?;
    _photo2 = snapshotData['photo2'] as String?;
    _photo3 = snapshotData['photo3'] as String?;
    _rentAmount = snapshotData['rent_amount'] as String?;
    _rooms = snapshotData['rooms'] as String?;
    _booked = snapshotData['booked'] as bool?;
    _ownerEmail = snapshotData['owner_email'] as String?;
    _tanentEmail = snapshotData['tanent_email'] as String?;
    _paid = snapshotData['paid'] as String?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('booked');

  static Stream<BookedRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => BookedRecord.fromSnapshot(s));

  static Future<BookedRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => BookedRecord.fromSnapshot(s));

  static BookedRecord fromSnapshot(DocumentSnapshot snapshot) => BookedRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static BookedRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      BookedRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'BookedRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is BookedRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createBookedRecordData({
  String? type,
  String? location,
  String? floorInfo,
  String? facilities,
  String? restrictions,
  String? contact,
  DateTime? availableDate,
  String? photo1,
  String? photo2,
  String? photo3,
  String? rentAmount,
  String? rooms,
  bool? booked,
  String? ownerEmail,
  String? tanentEmail,
  String? paid,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'type': type,
      'location': location,
      'floor_info': floorInfo,
      'facilities': facilities,
      'restrictions': restrictions,
      'contact': contact,
      'available_date': availableDate,
      'photo1': photo1,
      'photo2': photo2,
      'photo3': photo3,
      'rent_amount': rentAmount,
      'rooms': rooms,
      'booked': booked,
      'owner_email': ownerEmail,
      'tanent_email': tanentEmail,
      'paid': paid,
    }.withoutNulls,
  );

  return firestoreData;
}

class BookedRecordDocumentEquality implements Equality<BookedRecord> {
  const BookedRecordDocumentEquality();

  @override
  bool equals(BookedRecord? e1, BookedRecord? e2) {
    return e1?.type == e2?.type &&
        e1?.location == e2?.location &&
        e1?.floorInfo == e2?.floorInfo &&
        e1?.facilities == e2?.facilities &&
        e1?.restrictions == e2?.restrictions &&
        e1?.contact == e2?.contact &&
        e1?.availableDate == e2?.availableDate &&
        e1?.photo1 == e2?.photo1 &&
        e1?.photo2 == e2?.photo2 &&
        e1?.photo3 == e2?.photo3 &&
        e1?.rentAmount == e2?.rentAmount &&
        e1?.rooms == e2?.rooms &&
        e1?.booked == e2?.booked &&
        e1?.ownerEmail == e2?.ownerEmail &&
        e1?.tanentEmail == e2?.tanentEmail &&
        e1?.paid == e2?.paid;
  }

  @override
  int hash(BookedRecord? e) => const ListEquality().hash([
        e?.type,
        e?.location,
        e?.floorInfo,
        e?.facilities,
        e?.restrictions,
        e?.contact,
        e?.availableDate,
        e?.photo1,
        e?.photo2,
        e?.photo3,
        e?.rentAmount,
        e?.rooms,
        e?.booked,
        e?.ownerEmail,
        e?.tanentEmail,
        e?.paid
      ]);

  @override
  bool isValidKey(Object? o) => o is BookedRecord;
}
